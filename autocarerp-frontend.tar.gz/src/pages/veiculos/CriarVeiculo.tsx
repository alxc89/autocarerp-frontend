import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import veiculoService from "@/services/veiculo.service";
import type { VeiculoCreateDto } from "@/types/veiculo.types";

export default function CriarVeiculo() {
    const navigate = useNavigate();
    
    const [formData, setFormData] = useState<VeiculoCreateDto>({
        placa: "",
        marca: "",
        modelo: "",
        cor: "",
        ano: new Date().getFullYear()
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({ 
            ...formData, 
            [name]: name === 'ano' ? parseInt(value) || 0 : value 
        });
        if (error) setError(null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        try {
            setLoading(true);
            setError(null);

            await veiculoService.create(formData);
            
            navigate("/veiculos");
        } catch (err: any) {
            console.error('Error creating veiculo:', err);
            setError(err.response?.data?.message || 'Erro ao criar veículo. Tente novamente.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-1 flex-col gap-4 p-4">
            <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold">Cadastrar Veículo</h1>
                <Button 
                    variant="outline" 
                    onClick={() => navigate("/veiculos")}
                >
                    Voltar
                </Button>
            </div>

            <Card className="max-w-2xl">
                <CardHeader>
                    <CardTitle>Dados do Veículo</CardTitle>
                </CardHeader>
                <CardContent>
                    {error && (
                        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                            {error}
                        </div>
                    )}

                    <form className="space-y-4" onSubmit={handleSubmit}>
                        <div className="space-y-2">
                            <Label htmlFor="placa">Placa *</Label>
                            <Input
                                id="placa"
                                name="placa"
                                placeholder="ABC-1234"
                                value={formData.placa}
                                onChange={handleChange}
                                required
                                maxLength={10}
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="marca">Marca *</Label>
                            <Input
                                id="marca"
                                name="marca"
                                placeholder="Ex: Volkswagen, Fiat, Chevrolet"
                                value={formData.marca}
                                onChange={handleChange}
                                required
                                maxLength={15}
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="modelo">Modelo *</Label>
                            <Input
                                id="modelo"
                                name="modelo"
                                placeholder="Ex: Gol, Uno, Onix"
                                value={formData.modelo}
                                onChange={handleChange}
                                required
                                maxLength={15}
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="cor">Cor *</Label>
                            <Input
                                id="cor"
                                name="cor"
                                placeholder="Ex: Branco, Preto, Prata"
                                value={formData.cor}
                                onChange={handleChange}
                                required
                                maxLength={15}
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="ano">Ano *</Label>
                            <Input
                                id="ano"
                                name="ano"
                                type="number"
                                placeholder="2024"
                                value={formData.ano}
                                onChange={handleChange}
                                required
                                min={1900}
                                max={new Date().getFullYear() + 1}
                                disabled={loading}
                            />
                        </div>

                        <div className="flex gap-2 pt-4">
                            <Button 
                                type="submit" 
                                disabled={loading}
                            >
                                {loading ? "Salvando..." : "Salvar Veículo"}
                            </Button>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate("/veiculos")}
                                disabled={loading}
                            >
                                Cancelar
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
