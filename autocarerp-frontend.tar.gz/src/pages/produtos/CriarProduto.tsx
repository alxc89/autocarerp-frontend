import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import produtoService from "@/services/produto.service";
import type { ProdutoServicoCreateDto } from "@/types/produto.types";

export default function CriarProduto() {
    const navigate = useNavigate();
    
    const [formData, setFormData] = useState<ProdutoServicoCreateDto>({
        nome: "",
        descricao: "",
        fornecedor: "",
        custo: undefined,
        valor: 0
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        
        if (name === 'custo' || name === 'valor') {
            setFormData({ 
                ...formData, 
                [name]: value ? parseFloat(value) : (name === 'custo' ? undefined : 0)
            });
        } else {
            setFormData({ ...formData, [name]: value });
        }
        
        if (error) setError(null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        try {
            setLoading(true);
            setError(null);

            await produtoService.create(formData);
            
            navigate("/produtos");
        } catch (err: any) {
            console.error('Error creating produto:', err);
            setError(err.response?.data?.message || 'Erro ao criar produto/serviço. Tente novamente.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-1 flex-col gap-4 p-4">
            <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold">Cadastrar Produto/Serviço</h1>
                <Button 
                    variant="outline" 
                    onClick={() => navigate("/produtos")}
                >
                    Voltar
                </Button>
            </div>

            <Card className="max-w-2xl">
                <CardHeader>
                    <CardTitle>Dados do Produto/Serviço</CardTitle>
                </CardHeader>
                <CardContent>
                    {error && (
                        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                            {error}
                        </div>
                    )}

                    <form className="space-y-4" onSubmit={handleSubmit}>
                        <div className="space-y-2">
                            <Label htmlFor="nome">Nome *</Label>
                            <Input
                                id="nome"
                                name="nome"
                                placeholder="Nome do produto ou serviço"
                                value={formData.nome}
                                onChange={handleChange}
                                required
                                maxLength={30}
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="descricao">Descrição *</Label>
                            <Textarea
                                id="descricao"
                                name="descricao"
                                placeholder="Descrição detalhada"
                                value={formData.descricao}
                                onChange={handleChange}
                                required
                                maxLength={50}
                                disabled={loading}
                                rows={3}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="fornecedor">Fornecedor</Label>
                            <Input
                                id="fornecedor"
                                name="fornecedor"
                                placeholder="Nome do fornecedor"
                                value={formData.fornecedor || ""}
                                onChange={handleChange}
                                maxLength={30}
                                disabled={loading}
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="custo">Custo (opcional)</Label>
                                <Input
                                    id="custo"
                                    name="custo"
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    placeholder="0.00"
                                    value={formData.custo ?? ""}
                                    onChange={handleChange}
                                    disabled={loading}
                                />
                                <p className="text-xs text-muted-foreground">Valor de custo</p>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="valor">Valor de Venda *</Label>
                                <Input
                                    id="valor"
                                    name="valor"
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    placeholder="0.00"
                                    value={formData.valor}
                                    onChange={handleChange}
                                    required
                                    disabled={loading}
                                />
                                <p className="text-xs text-muted-foreground">Preço de venda</p>
                            </div>
                        </div>

                        <div className="flex gap-2 pt-4">
                            <Button 
                                type="submit" 
                                disabled={loading}
                            >
                                {loading ? "Salvando..." : "Salvar Produto/Serviço"}
                            </Button>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate("/produtos")}
                                disabled={loading}
                            >
                                Cancelar
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}