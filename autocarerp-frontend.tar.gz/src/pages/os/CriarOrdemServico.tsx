import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ordemServicoService from "@/services/ordem-servico.service";
import clienteService from "@/services/cliente.service";
import veiculoService from "@/services/veiculo.service";
import produtoService from "@/services/produto.service";
import type { OrdemDeServicoCreateDto } from "@/types/ordem-servico.types";
import type { ClienteReadDto } from "@/types/cliente.types";
import type { VeiculoReadDto } from "@/types/veiculo.types";
import type { ProdutoServicoReadDto } from "@/types/produto.types";

export default function CriarOrdemServico() {
    const navigate = useNavigate();
    
    const [formData, setFormData] = useState<OrdemDeServicoCreateDto>({
        horaAbertura: new Date().toISOString().slice(0, 16), // YYYY-MM-DDTHH:mm
        horaFechamento: undefined,
        veiculoId: 0,
        clienteId: 0,
        produtoServicoId: 0,
        quantidade: 1,
        valorUnitario: 0,
        valorTotal: 0,
        observacao: "",
        status: "ABERTA"
    });

    const [clientes, setClientes] = useState<ClienteReadDto[]>([]);
    const [veiculos, setVeiculos] = useState<VeiculoReadDto[]>([]);
    const [produtos, setProdutos] = useState<ProdutoServicoReadDto[]>([]);
    const [loading, setLoading] = useState(false);
    const [loadingData, setLoadingData] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadInitialData = async () => {
            try {
                setLoadingData(true);
                const [clientesResult, veiculosResult, produtosResult] = await Promise.all([
                    clienteService.getAll({ page: 1, pageSize: 100 }),
                    veiculoService.getAll({ page: 1, pageSize: 100 }),
                    produtoService.getAll({ page: 1, pageSize: 100 })
                ]);
                
                setClientes(clientesResult.items);
                setVeiculos(veiculosResult.items);
                setProdutos(produtosResult.items);
            } catch (err: any) {
                console.error('Error loading data:', err);
                setError('Erro ao carregar dados. Tente novamente.');
            } finally {
                setLoadingData(false);
            }
        };

        loadInitialData();
    }, []);

    // Recalculate valorTotal when quantidade or valorUnitario changes
    useEffect(() => {
        const total = formData.quantidade * formData.valorUnitario;
        if (formData.valorTotal !== total) {
            setFormData(prev => ({ ...prev, valorTotal: total }));
        }
    }, [formData.quantidade, formData.valorUnitario]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        
        if (name === 'quantidade' || name === 'valorUnitario') {
            setFormData({ ...formData, [name]: parseFloat(value) || 0 });
        } else {
            setFormData({ ...formData, [name]: value });
        }
        
        if (error) setError(null);
    };

    const handleSelectChange = (name: string, value: string) => {
        if (name === 'produtoServicoId') {
            const produto = produtos.find(p => p.codigo === parseInt(value));
            setFormData({ 
                ...formData, 
                [name]: parseInt(value),
                valorUnitario: produto?.valor || 0
            });
        } else {
            setFormData({ ...formData, [name]: parseInt(value) });
        }
        if (error) setError(null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!formData.clienteId || !formData.veiculoId || !formData.produtoServicoId) {
            setError('Por favor, selecione cliente, veículo e produto/serviço');
            return;
        }

        try {
            setLoading(true);
            setError(null);

            await ordemServicoService.create({
                ...formData,
                horaAbertura: new Date(formData.horaAbertura).toISOString()
            });
            
            navigate("/ordem-servico");
        } catch (err: any) {
            console.error('Error creating ordem de servico:', err);
            setError(err.response?.data?.message || 'Erro ao criar ordem de serviço. Tente novamente.');
        } finally {
            setLoading(false);
        }
    };

    if (loadingData) {
        return (
            <div className="flex flex-1 items-center justify-center p-4">
                <p>Carregando dados...</p>
            </div>
        );
    }

    return (
        <div className="flex flex-1 flex-col gap-4 p-4">
            <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold">Abrir Ordem de Serviço</h1>
                <Button 
                    variant="outline" 
                    onClick={() => navigate("/ordem-servico")}
                >
                    Voltar
                </Button>
            </div>

            <Card className="max-w-3xl">
                <CardHeader>
                    <CardTitle>Dados da Ordem de Serviço</CardTitle>
                </CardHeader>
                <CardContent>
                    {error && (
                        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                            {error}
                        </div>
                    )}

                    <form className="space-y-4" onSubmit={handleSubmit}>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="clienteId">Cliente *</Label>
                                <Select 
                                    onValueChange={(value) => handleSelectChange('clienteId', value)}
                                    disabled={loading}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Selecione um cliente" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {clientes.map((cliente) => (
                                            <SelectItem key={cliente.codigo} value={cliente.codigo.toString()}>
                                                {cliente.nome}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="veiculoId">Veículo *</Label>
                                <Select 
                                    onValueChange={(value) => handleSelectChange('veiculoId', value)}
                                    disabled={loading}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Selecione um veículo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {veiculos.map((veiculo) => (
                                            <SelectItem key={veiculo.codigo} value={veiculo.codigo.toString()}>
                                                {veiculo.placa} - {veiculo.marca} {veiculo.modelo}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="produtoServicoId">Produto/Serviço *</Label>
                            <Select 
                                onValueChange={(value) => handleSelectChange('produtoServicoId', value)}
                                disabled={loading}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Selecione um produto/serviço" />
                                </SelectTrigger>
                                <SelectContent>
                                    {produtos.map((produto) => (
                                        <SelectItem key={produto.codigo} value={produto.codigo.toString()}>
                                            {produto.nome} - R$ {produto.valor.toFixed(2)}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="quantidade">Quantidade *</Label>
                                <Input
                                    id="quantidade"
                                    name="quantidade"
                                    type="number"
                                    min="1"
                                    value={formData.quantidade}
                                    onChange={handleChange}
                                    required
                                    disabled={loading}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="valorUnitario">Valor Unitário *</Label>
                                <Input
                                    id="valorUnitario"
                                    name="valorUnitario"
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={formData.valorUnitario}
                                    onChange={handleChange}
                                    required
                                    disabled={loading}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="valorTotal">Valor Total</Label>
                                <Input
                                    id="valorTotal"
                                    name="valorTotal"
                                    type="number"
                                    step="0.01"
                                    value={formData.valorTotal}
                                    disabled
                                    className="bg-muted"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="horaAbertura">Data/Hora de Abertura *</Label>
                            <Input
                                id="horaAbertura"
                                name="horaAbertura"
                                type="datetime-local"
                                value={formData.horaAbertura}
                                onChange={handleChange}
                                required
                                disabled={loading}
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="status">Status *</Label>
                            <Select 
                                value={formData.status}
                                onValueChange={(value) => setFormData({ ...formData, status: value })}
                                disabled={loading}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="ABERTA">Aberta</SelectItem>
                                    <SelectItem value="EM_ANDAMENTO">Em Andamento</SelectItem>
                                    <SelectItem value="FINALIZADA">Finalizada</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="observacao">Observações</Label>
                            <Textarea
                                id="observacao"
                                name="observacao"
                                placeholder="Observações sobre a ordem de serviço"
                                value={formData.observacao || ""}
                                onChange={handleChange}
                                maxLength={50}
                                disabled={loading}
                                rows={3}
                            />
                        </div>

                        <div className="flex gap-2 pt-4">
                            <Button 
                                type="submit" 
                                disabled={loading}
                            >
                                {loading ? "Salvando..." : "Abrir Ordem de Serviço"}
                            </Button>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate("/ordem-servico")}
                                disabled={loading}
                            >
                                Cancelar
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}